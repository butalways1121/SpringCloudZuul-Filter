package com.SpringBootZuulFilterServer1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * Hello world!
 *
 */
@EnableDiscoveryClient
@SpringBootApplication
public class ZuulFilterServer1 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(ZuulFilterServer1.class, args);
        System.out.println("zuul-filter第一个服务启动....");
    }
}
