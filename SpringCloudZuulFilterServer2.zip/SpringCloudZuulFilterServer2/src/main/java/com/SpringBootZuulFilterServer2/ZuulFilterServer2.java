package com.SpringBootZuulFilterServer2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * Hello world!
 *
 */
@EnableDiscoveryClient
@SpringBootApplication
public class ZuulFilterServer2 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(ZuulFilterServer2.class, args);
        System.out.println("zuul-filter第二个服务启动....");
    }
}
