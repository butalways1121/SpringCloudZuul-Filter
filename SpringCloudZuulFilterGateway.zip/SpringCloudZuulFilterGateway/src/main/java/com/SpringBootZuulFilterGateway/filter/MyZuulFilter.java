package com.SpringBootZuulFilterGateway.filter;

import javax.servlet.http.HttpServletRequest;

import org.springframework.cloud.netflix.zuul.filters.support.FilterConstants;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

/**
 * 
* @Title: MyZuulFilter
* @Description: 自定义过滤器实现类,用于校验请求参数是否合法
 */
@Component
public class MyZuulFilter extends ZuulFilter{

	//shouldFilter()方法表示是否执行该过滤器，也可以说是该过滤器的一个开关
	@Override
	public boolean shouldFilter() {
		//此方法可以根据请求的url进行判断是否需要拦截
		return true;
	}

	//run()方法是过滤器的具体逻辑。在该函数中，我们可以实现自定义的过滤逻辑，来确定是否要拦截当前的请求，不对其进行后续的路由，或是在请求路由返回结果之后，对处理结果做一些加工等
	//获取请求的url，如果该url携带了token，我们就让他通过，否则直接拦截
	@Override
	public Object run() throws ZuulException {
		//获取请求的上下文类 注意是：com.netflix.zuul.context包下的
		RequestContext ctx = RequestContext.getCurrentContext();
		HttpServletRequest request = ctx.getRequest();
		ctx.addZuulResponseHeader("Content-type", "text/json;charset=UTF-8");
		ctx.getResponse().setCharacterEncoding("UTF-8");
		System.out.println("请求地址:"+request.getRequestURI());
		String token = request.getParameter("token");
		String msg="请求成功!";
		if(token==null) {
			//使其不进行转发
		   ctx.setSendZuulResponse(false);
		   msg="请求失败！原因是token为空！";
		   ctx.setResponseBody(msg);
		   ctx.setResponseStatusCode(HttpStatus.UNAUTHORIZED.value());
		   //或者添加一个额外参数也可以 传递参数可以使用
//		   ctx.set("checkAuth",false);
		}
		System.out.println(msg);
		return msg;
	}

	//设置为前置过滤器，在请求被路由之前调用
	@Override
	public String filterType() {
		//前置过滤器
		return FilterConstants.PRE_TYPE;
	}

	@Override
	public int filterOrder() {
		//执行顺序  0 靠前执行 在spring cloud zuul提供的pre过滤器之后执行，默认的是小于0的。	
		//除了参数校验类的过滤器 一般上直接放在 PreDecoration前
		//即：PRE_DECORATION_FILTER_ORDER - 1;
		//常量类都在：org.springframework.cloud.netflix.zuul.filters.support.FilterConstants 下
		return 0;
	}
	
	//将该过滤类使用Bean注解使其生效
	@Bean
	public MyZuulFilter zuulFilter() {
	    return new MyZuulFilter();
	}

}

